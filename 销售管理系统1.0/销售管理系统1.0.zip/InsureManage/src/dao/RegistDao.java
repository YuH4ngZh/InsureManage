package dao;

import model.User;

public interface RegistDao {
	public void Regist(User login);
}
